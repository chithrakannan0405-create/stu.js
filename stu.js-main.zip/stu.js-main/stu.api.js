
const Student = require("../models/Student");

// READ: Get all students
exports.getAllStudents = (req, res) => {
  res.status(200).json(Student.getAll());
};

// READ: Get one student
exports.getStudentById = (req, res) => {
  const id = Number(req.params.id);
  const student = Student.getById(id);

  if (!student) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  res.status(200).json(student);
};

// CREATE: Add a student
exports.createStudent = (req, res) => {
  const { name, age, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    !Number.isInteger(age) ||
    age < 1 ||
    typeof course !== "string" ||
    !course.trim()
  ) {
    return res.status(400).json({
      message: "Provide a valid name, age, and course"
    });
  }

  const student = Student.create({
    name: name.trim(),
    age,
    course: course.trim()
    
  });

  res.status(201).json({
    message: "Student created successfully",
    student
  });
};

// UPDATE: Edit a student
exports.updateStudent = (req, res) => {
  const id = Number(req.params.id);
  const { name, age, course } = req.body;

  if (
    typeof name !== "string" ||
    !name.trim() ||
    !Number.isInteger(age) ||
    age < 1 ||
    typeof course !== "string" ||
    !course.trim()
  ) {
    return res.status(400).json({
      message: "Provide a valid name, age, and course"
    });
  }

  const student = Student.update(id, {
    name: name.trim(),
    age,
    course: course.trim()
  });

  if (!student) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  res.status(200).json({
    message: "Student updated successfully",
    student
  });
};

// DELETE: Remove a student
exports.deleteStudent = (req, res) => {
  const id = Number(req.params.id);
  const deleted = Student.delete(id);

  if (!deleted) {
    return res.status(404).json({
      message: "Student not found"
    });
  }

  res.status(200).json({
    message: "Student deleted successfully"
  });
};